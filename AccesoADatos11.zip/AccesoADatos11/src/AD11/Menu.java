package AD11;

import java.sql.*;
import java.util.*;
import java.io.*;
import org.json.*;

public class Menu {

	private static final Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		try (Connection conexion = DriverManager.getConnection(
				"jdbc:mysql://localhost:3306/Alumnos01?useSSL=false&serverTimezone=UTC", "ADManager", "manager");
				Statement sentencia = conexion.createStatement();) {
			int opcion;
			do {
				mostrarMenu();
				opcion = sc.nextInt();
				sc.nextLine();

				switch (opcion) {
				case 1: {
					Alumno aux = crearAlumno();
					insertarAlumno(aux, sentencia);
					break;
				}
				case 2: {
					mostrarAlumnos(sentencia);
					break;
				}
				case 3: {
					exportarTXT(sentencia);
					break;
				}
				case 4: {
					importarTXT(sentencia);
					break;
				}
				case 5: {
					modificarNombrePK(sentencia);
					break;
				}
				case 6: {
					eliminarAlumnoPK(sentencia);
					break;
				}
				case 7: {
					eliminarAlumnosApellidos(sentencia);
					break;
				} 
				case 8:{
					exportarJSON(sentencia);
					break;
				}
				case 9: {
					importarJSON(sentencia);
					break;
				}
				case 0:{
					System.out.println("Adios");
					break;
				}
				default:
					System.out.println("Opción inválida.");
				}
			} while (opcion != 0);
		} catch (Exception e) {

		}
	}

	private static void mostrarMenu() {
		System.out.println(" MENU ");
		System.out.println("1. Insertar alumno");
		System.out.println("2. Mostrar alumnos");
		System.out.println("3. Guardar alumnos en TXT");
		System.out.println("4. Leer alumnos de TXT y pasarlos a la BBDD");
		System.out.println("5. Actualizar alumno nombre por la PK");
		System.out.println("6. Eliminar alumno por su PK");
		System.out.println("7. Eliminar alumno por su apellido");
		System.out.println("8. Exportar alumnos a JSON");
		System.out.println("9. Importar alumnos desde JSON");
		System.out.println("0. Salir");
	}

	public static Alumno crearAlumno() {
		int nia, dia, mes, anio;
		String nombre, apellidos, ciclo, curso, grupo;
		char genero;
		System.out.println("Nia:");
		nia = sc.nextInt();
		sc.nextLine();
		System.out.println("Nombre:");
		nombre = sc.nextLine();
		System.out.println("Apellidos:");
		apellidos = sc.nextLine();
		System.out.println("Genero:");
		genero = sc.nextLine().charAt(0);
		System.out.println("Año de nacimiento:");
		anio = sc.nextInt();
		System.out.println("Mes de nacimiento:");
		mes = sc.nextInt();
		System.out.println("Dia de nacimiento:");
		dia = sc.nextInt();
		sc.nextLine();
		System.out.println("Curso:");
		curso = sc.nextLine();
		System.out.println("Ciclo:");
		ciclo = sc.nextLine();
		System.out.println("Grupo:");
		grupo = sc.nextLine();
		return new Alumno(nia, nombre, apellidos, genero, anio, mes, dia, ciclo, curso, grupo);
	}

	// SQL
	public static void insertarAlumno(Alumno aux, Statement sentencia) {
		try {
			String consulta = "INSERT INTO alumnos (Nia, Nombre, Apellidos, Genero, FechaNac, Curso, Ciclo, Grupo)\n"
					+ "VALUES ('" + aux.getNia() + "', '" + aux.getNombre() + "', '" + aux.getApellidos() + "', '"
					+ aux.getGenero() + "', '" + aux.fechaNacimientoSQL() + " 00:00:00', '" + aux.getCurso() + "', '"
					+ aux.getCiclo() + "', '" + aux.getGrupo() + "');";
			int resul = sentencia.executeUpdate(consulta);
			System.out.println("Alumno creado correctamente");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void mostrarAlumnos(Statement sentencia) {
		try {
			String consulta = "SELECT Nia, Nombre, Apellidos, Genero, FechaNac, Curso, Ciclo, Grupo \n FROM alumnos";
			ResultSet resul = sentencia.executeQuery(consulta);
			while (resul.next()) {
				System.out.printf("%d, %s, %s, %s, %s, %s, %s, %s%n", resul.getInt(1), resul.getString(2),
						resul.getString(3), resul.getString(4), resul.getString(5), resul.getString(6),
						resul.getString(7), resul.getString(8));
			}
		} catch (Exception e) {
			e.getStackTrace();
		}
	}

	public static void eliminarAlumnoPK(Statement sentencia) {
		System.out.println("Indique el NIA del alumno a eliminar");
		String primaryKey = sc.nextLine();
		try {
			int resul = sentencia.executeUpdate("DELETE FROM alumnos WHERE Nia = " + primaryKey);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void eliminarAlumnosApellidos(Statement sentencia) {
		System.out.println("Indique la palabra que contra el apellido de los alumnos que desea eliminar");
		String palabraEliminar = sc.nextLine();
		try {
			int resul = sentencia.executeUpdate("DELETE FROM alumnos WHERE Apellidos LIKE '%" + palabraEliminar + "%'");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void modificarNombrePK(Statement sentencia) {
		System.out.println("Indique el NIA del alumno a modificar");
		String primaryKey = sc.nextLine();
		System.out.println("Indique el nuevo nombre de la persona");
		String nombreNuevo = sc.nextLine();
		try {
			int resul = sentencia
					.executeUpdate("UPDATE alumnos SET Nombre = '" + nombreNuevo + "' WHERE Nia = " + primaryKey);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// JSON

	private static void exportarJSON(Statement sentencia) {
		try (FileWriter fw = new FileWriter("alumnos.json");){
			JSONArray arr = new JSONArray();
			ResultSet rs = sentencia.executeQuery(
						    "SELECT Nia, Nombre, Apellidos, Genero, FechaNac, Curso, Ciclo, Grupo FROM alumnos");


			while (rs.next()) {
				JSONObject o = new JSONObject();
				o.put("Nia", rs.getInt(1));
				o.put("Nombre", rs.getString(2));
				o.put("Apellidos", rs.getString(3));
				o.put("Genero", rs.getString(4));
				o.put("FechaNac", rs.getString(5));
				o.put("Curso", rs.getString(6));
				o.put("Ciclo", rs.getString(7));
				o.put("Grupo", rs.getString(8));
				arr.put(o);
			}
			
			fw.write(arr.toString());
		} catch (Exception e) {
			System.out.println("ERROR JSON: " + e.getMessage());
		}
	}

	private static void importarJSON(Statement sentencia) {
		try {
			System.out.print("Ruta del JSON: ");
			String ruta = sc.nextLine();

			StringBuilder sb = new StringBuilder();
			try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
				String linea;
				while ((linea = br.readLine()) != null) {
					sb.append(linea);
				}
			}
			JSONArray arr = new JSONArray(sb.toString());
			for (int i = 0; i < arr.length(); i++) {
				JSONObject o = arr.getJSONObject(i);

				String sql = "INSERT INTO alumnos VALUES (" + o.getInt("Nia") + ", '" + o.getString("Nombre") + "', '"
						+ o.getString("Apellidos") + "', '" + o.getString("Genero") + "', '" + o.getString("FechaNac")
						+ "', '" + o.getString("Curso") + "', '" + o.getString("Ciclo") + "', '" + o.getString("Grupo")
						+ "')";

				sentencia.executeUpdate(sql);
			}
		} catch (Exception e) {
			System.out.println("ERROR: " + e.getMessage());
		}
	}
	
	// txt
	private static void exportarTXT(Statement sentencia) {
	    System.out.print("Ruta del archivo TXT: ");
	    String ruta = sc.nextLine();
	    try (
	         PrintWriter pw = new PrintWriter(new FileWriter(ruta))) {

	        ResultSet rs = sentencia.executeQuery("SELECT Nia, Nombre, Apellidos, Genero, FechaNac, Curso, Ciclo, Grupo \n FROM alumnos");
	        while (rs.next()) {
	            pw.printf("%d/%s/%s/%s/%s/%s/%s/%s%n",
	                    rs.getInt("Nia"),
	                    rs.getString("Nombre"),
	                    rs.getString("Apellidos"),
	                    rs.getString("Genero"),
	                    rs.getString("FechaNac"),
	                    rs.getString("Curso"),
	                    rs.getString("Ciclo"),
	                    rs.getString("Grupo"));
	        }
	    } catch (Exception e) {
	        System.out.println("ERROR: " + e.getMessage());
	    }
	}
	private static void importarTXT(Statement sentencia) {
	    System.out.print("Ruta del archivo TXT: ");
	    String ruta = sc.nextLine();
	    try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
	        String linea;
	        while ((linea = br.readLine()) != null) {
	            String[] datos = linea.split("/");
	            String sql = "INSERT INTO alumnos VALUES (" +
	                    datos[0] + ", '" +  
	                    datos[1] + "', '" +  
	                    datos[2] + "', '" +  
	                    datos[3] + "', '" +  
	                    datos[4] + "', '" +  
	                    datos[5] + "', '" +  
	                    datos[6] + "', '" +  
	                    datos[7] + "')";     

	            sentencia.executeUpdate(sql);
	        }
	    } catch (Exception e) {
	        System.out.println("ERROR: " + e.getMessage());
	    }
	}

}
